<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = strip_tags(trim($_POST["nome"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $mensagem = strip_tags(trim($_POST["mensagem"]));

    if (empty($nome) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($mensagem)) {
        http_response_code(400);
        echo "Por favor, preencha todos os campos corretamente.";
        exit;
    }

    $destinatario = "comercial@mentesqueinspiram.com";
    $assunto = "Nova Proposta: $nome - Mentes que Inspiram";

    $corpo_email = "Nome: $nome\n";
    $corpo_email .= "Email: $email\n\n";
    $corpo_email .= "Mensagem:\n$mensagem\n";

    $cabecalhos = "From: $nome <$email>";

    if (mail($destinatario, $assunto, $corpo_email, $cabecalhos)) {
        // Sucesso: Redireciona de volta para o site com um parâmetro de sucesso
        header("Location: index.html?status=success#contact");
    } else {
        http_response_code(500);
        echo "Ocorreu um erro ao enviar sua mensagem.";
    }
} else {
    http_response_code(403);
    echo "Houve um problema com sua submissão, tente novamente.";
}
?>
